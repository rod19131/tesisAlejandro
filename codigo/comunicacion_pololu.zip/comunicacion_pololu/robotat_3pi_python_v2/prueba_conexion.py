from robotat_connect import *
from robotat_disconnect import *
from robotat_get_pose import *

robotat = robotat_connect()
try:
    print(robotat)
    #disconnect = int(input("desconectar?"))
    pose = robotat_get_pose(robotat, [1], "quat")
    #print(pose)
except:
    pass
finally:
    robotat_disconnect(robotat)
        
